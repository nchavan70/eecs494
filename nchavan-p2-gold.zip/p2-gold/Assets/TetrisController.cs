using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TetrisController : MonoBehaviour
{
    //Rigidbody rb;
    public bool specialCollider = true;
    bool grounded = false;

    private SpriteRenderer sp;

    // Start is called before the first frame update
    void Start()
    {
        //rb = GetComponent<Rigidbody>();
        sp = GetComponent<SpriteRenderer>();
        sp.color = new Color(1, 1, 1, 0.5f);
    }

    // Update is called once per frame
    void Update()
    {
        // Move down
        /*if (!grounded) {
            Vector3 pos = transform.position;
            pos.y -= 0.01f;
            transform.position = pos;
        }*/
        handleMovement();
    }

    private void handleMovement()
    {
        if (grounded)
            return;
        float curX = transform.position.x;
        float curY = transform.position.y;
        if (Input.GetKeyDown(KeyCode.W))
            curY += 1;
        else if (Input.GetKeyDown(KeyCode.S))
            curY -= 1;
        else if (Input.GetKeyDown(KeyCode.A))
            curX -= 1;
        else if (Input.GetKeyDown(KeyCode.D))
            curX += 1;
        transform.position = new Vector2(curX, curY);

        if (Input.GetKeyDown(KeyCode.Q)) {
            float curDir = transform.localScale.x;
            transform.localScale = new Vector3(curDir * -1, 1, 0);
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        //print("[Block] " + collision.gameObject.tag.ToString());
    }

    private void OnTriggerEnter(Collider other)
    {
        // Only land once
        if (grounded || other.gameObject.CompareTag("Enemy")) {
            return;
        }
        print(other.gameObject.tag.ToString());
        grounded = true;
        sp.color = new Color(1, 1, 1, 1f);

        if (specialCollider)
        {
            Collider[] stuff = gameObject.GetComponentsInChildren<Collider>();
            for (int x = 0; x < stuff.Length; ++x)
                stuff[x].isTrigger = false;
        }
        else
        {
            GetComponent<Collider>().isTrigger = false;
        }
        LevelManagerScript.instance.blockSpawned = false;

        if (gameObject.CompareTag("YellowBlock") && other.gameObject.CompareTag("Button"))
        {
            print("Pressing button");
            YellowButtonControl ybc = other.gameObject.GetComponent<YellowButtonControl>();
            ybc.isPressed = true;
            other.gameObject.GetComponent<SpriteRenderer>().sprite = ybc.pressedButton;

        }
    }
}
