Find more classic-game assets at https://www.spriters-resource.com/ (But don't forget to credit them as per the project spec)

Some assets find use in just about any project. Assets like black_pixel. You might consider grabbing a white_pixel asset from google, so you have a freely-colorable block.