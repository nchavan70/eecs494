using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletControl : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //Vector3 pos = transform.position;
        //pos.y -= 0.1f;
        //transform.position = pos;
        //GetComponent<Rigidbody>().velocity = new Vector3(0, -2f, 0);
    }

    private void OnTriggerEnter(Collider other)
    {
        print("[Bullet] Trigger!");
        print("[Bullet] " + other.gameObject.tag.ToString());
        if (other.gameObject.CompareTag("Ground") || other.gameObject.CompareTag("OrangeBlock")
            || other.gameObject.CompareTag("Wall")) {
            Destroy(gameObject);
        }
        else if (other.gameObject.CompareTag("Player"))
            LevelManagerScript.instance.restartLevel();

    }
}
