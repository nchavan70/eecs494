using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonManager : MonoBehaviour
{
    public GameObject[] yellowButtons;
    public GameObject door;

    // Start is called before the first frame update
    void Start()
    {
        door.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        checkButtons();
    }

    private void checkButtons()
    {
        for (int x = 0; x < yellowButtons.Length; ++x)
        {
            if (!yellowButtons[x].GetComponent<YellowButtonControl>().isPressed)
                return;
        }
        // If we made it to here, all buttons are pressed
        door.SetActive(true);
    }
}
