using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class TetrisSpawner : MonoBehaviour
{
    public GameObject[] tetrisPieces;
    public int[] tetrisCounts;
    //public TMP_Text[] blockCountTexts;

    private GameObject player;
    private enum tetrisID {Blue, Yellow, Orange, Green, Pink};
    private TMP_Text blueCountText, yellowCountText, orangeCountText,greenCountText,
        pinkCountText;

    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.Find("Player");

        blueCountText = GameObject.Find("BlueCountText").GetComponent<TMP_Text>();
        yellowCountText = GameObject.Find("YellowCountText").GetComponent<TMP_Text>();
        orangeCountText = GameObject.Find("OrangeCountText").GetComponent<TMP_Text>();
        greenCountText = GameObject.Find("GreenCountText").GetComponent<TMP_Text>();
        pinkCountText = GameObject.Find("PinkCountText").GetComponent<TMP_Text>();
    }

    // Update is called once per frame
    void Update()
    {
        // If no block spawned, spawn randomly
        /*if (LevelManagerScript.instance.blockSpawned == false)
        {
            // Spawn block
            LevelManagerScript.instance.blockSpawned = true;
            GameObject player = GameObject.Find("Player");
            Vector3 pos = player.transform.position;
            pos.y += 8;
            Object.Instantiate(tetrisPieces[0], pos, Quaternion.Euler(0, 0, 0), player.transform);
        }*/
        handleSpawn();
        updateText();
    }

    private void handleSpawn()
    {
        // Only one block can be spawned at a time
        if (LevelManagerScript.instance.blockSpawned)
            return;

        if (Input.GetKeyDown(KeyCode.Alpha1) && tetrisCounts[(int) tetrisID.Blue] > 0)
            spawn((int) tetrisID.Blue);
        else if (Input.GetKeyDown(KeyCode.Alpha2) && tetrisCounts[(int)tetrisID.Yellow] > 0)
            spawn((int)tetrisID.Yellow);
        else if (Input.GetKeyDown(KeyCode.Alpha3) && tetrisCounts[(int)tetrisID.Orange] > 0)
            spawn((int)tetrisID.Orange);
        else if (Input.GetKeyDown(KeyCode.Alpha4) && tetrisCounts[(int)tetrisID.Green] > 0)
            spawn((int)tetrisID.Green);
        else if (Input.GetKeyDown(KeyCode.Alpha5) && tetrisCounts[(int)tetrisID.Pink] > 0)
            spawn((int)tetrisID.Pink);
    }

    private void spawn(int id)
    {
        Vector3 pos = player.transform.position;
        pos.y += 8;

        Object.Instantiate(tetrisPieces[id], pos, Quaternion.Euler(0, 0, 0));
        tetrisCounts[id] -= 1;
        LevelManagerScript.instance.blockSpawned = true;
    }

    private void updateText()
    {
        blueCountText.text = "x" + tetrisCounts[(int)tetrisID.Blue].ToString();
        yellowCountText.text = "x" + tetrisCounts[(int)tetrisID.Yellow].ToString();
        orangeCountText.text = "x" + tetrisCounts[(int)tetrisID.Orange].ToString();
        greenCountText.text = "x" + tetrisCounts[(int)tetrisID.Green].ToString();
        pinkCountText.text = "x" + tetrisCounts[(int)tetrisID.Pink].ToString();
    }
}
