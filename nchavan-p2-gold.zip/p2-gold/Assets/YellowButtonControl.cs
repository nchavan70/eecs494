using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class YellowButtonControl : MonoBehaviour
{
    public Sprite pressedButton;
    public bool isPressed = false;

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("YellowBlock")) {
            GetComponent<SpriteRenderer>().sprite = pressedButton;
            isPressed = true;
        }
    }
}
