using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OrangeEnemyControl : MonoBehaviour
{
    public float startDelay = 0;
    public GameObject bulletPrefab;
    public float xDir = 0;
    public float yDir = -1;
    public float bulletSpeed = 10f;
    public float shootGap = 1.5f;

    private bool canShoot = false;

    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(wait());
    }

    // Update is called once per frame
    void Update()
    {

    }

    private IEnumerator wait()
    {
        yield return new WaitForSeconds(startDelay);
        yield return StartCoroutine(shootControl());
    }

    private IEnumerator shootControl()
    {
        while (true)
        {
            Vector3 pos = transform.position;
            Quaternion temp = Quaternion.Euler(0, 0, 0);
            if (Mathf.Abs(xDir) > 0)
                temp = Quaternion.Euler(0, 0, -90);

            GameObject bullet = Object.Instantiate(bulletPrefab, pos, temp);
            bullet.GetComponent<Rigidbody>().velocity = new Vector2(xDir, yDir) * bulletSpeed;
            yield return new WaitForSeconds(shootGap);
        }
    }
}
