using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformController : MonoBehaviour
{
    public float travelTime = 1f;
    public float maxTravelDistance = 6f;
    public float restTime = 2f;

    private Vector2 initialPosition;
    private Vector2 finalPosition;

    // Start is called before the first frame update
    void Start()
    {
        initialPosition = transform.position;

        finalPosition = initialPosition;
        finalPosition.x -= maxTravelDistance;

        StartCoroutine(movePlatform());
    }

    private IEnumerator movePlatform()
    {
        while (true)
        {
            yield return StartCoroutine(
                CoroutineUtils.MoveObjectOverTime(transform, initialPosition,
                finalPosition, travelTime)
            );

            yield return new WaitForSeconds(restTime);

            // Glide backward
            yield return StartCoroutine(
                CoroutineUtils.MoveObjectOverTime(transform, finalPosition,
                initialPosition, travelTime)
            );

            yield return new WaitForSeconds(restTime);
        }
    }
}
