using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelManagerScript : MonoBehaviour
{
    public static LevelManagerScript instance;
    public string restartTo;
    public string nextLevel;

    public bool blockSpawned = false;

    private void Awake()
    {
        if (instance == null)
            instance = this;
        else
            Destroy(gameObject);
        Screen.SetResolution(1600, 900, false);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
            restartLevel();
        if (Input.GetKeyDown(KeyCode.T))
            enterNextLevel();
    }

    public void restartLevel()
    {
        SceneManager.LoadScene(restartTo);
    }

    public void enterNextLevel()
    {
        SceneManager.LoadScene(nextLevel);
    }
}
