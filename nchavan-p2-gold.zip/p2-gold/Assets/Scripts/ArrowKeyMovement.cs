using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArrowKeyMovement : MonoBehaviour
{
    public float speed = 8;
    public float startDashTimer;
    public float dashForce;

    private Rigidbody rb;
    private Animator anim;
    private bool isDashing = false;
    private bool dashedOnce = false;
    private float currentDashTimer;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        //dash(getInput());
        rb.velocity = new Vector2(speed * getInput(), rb.velocity.y);
        //checkFalling();
    }

    private void FixedUpdate()
    {
        if (rb.useGravity)
            rb.AddForce(Vector3.down * rb.mass);
    }

    private float getInput()
    {
        float horiz = Input.GetAxisRaw("Horizontal");
        float vert = Input.GetAxisRaw("Vertical");

        anim.SetFloat("horizontal", horiz);
        anim.SetFloat("vertical", vert);

        if (Mathf.Abs(horiz) > 0)
            anim.speed = 4f;
        else
            anim.speed = 1f;

        return horiz;
    }

    private void dash(float xVelocity)
    {
        if (Input.GetKeyDown(KeyCode.X) && !isDashing && !dashedOnce)
        {
            isDashing = true;
            dashedOnce = true;
            currentDashTimer = startDashTimer;
            GetComponent<SpriteRenderer>().color = Color.blue;

            // Disable graviy until dash is finished
            rb.useGravity = false;
        }

        if (isDashing)
        {
            rb.velocity = new Vector2(speed * dashForce * xVelocity, rb.velocity.y);
            currentDashTimer -= Time.deltaTime;
            if (currentDashTimer <= 0)
            {
                isDashing = false;
                rb.useGravity = true;
                GetComponent<SpriteRenderer>().color = Color.white;
            }
        }
        else
        {
            rb.velocity = new Vector2(speed * xVelocity, rb.velocity.y);
        }
    }

    private void checkFalling()
    {
        RaycastHit hit;
        if (Physics.Raycast(transform.position, Vector3.down, out hit, Mathf.Infinity)) {
            print(hit.distance);
            if (hit.distance > 0.53)
                rb.useGravity = true;
            else if (hit.distance <= 0.53 && dashedOnce)
                dashedOnce = false;
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        // Should only dash once after jumping
        print(collision.gameObject.tag);
        if (collision.gameObject.CompareTag("Ground") ||
        collision.gameObject.CompareTag("Block") ||
        collision.gameObject.CompareTag("OrangeBlock") ||
        collision.gameObject.CompareTag("YellowBlock")) {
            dashedOnce = false;

            // Move the player up a little and turn off gravity
            /*rb.useGravity = false;
            Vector3 curPos = transform.position;
            curPos.y += 0.01f;
            transform.position = curPos;*/

            // Inside update() use RayCasting to re-enable gravity
        }
    }
}
