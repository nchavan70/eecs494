using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Jump : MonoBehaviour
{
    private Rigidbody rb;
    private bool onGround = false;

    public float jumpForce = 0.75f;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.UpArrow) && onGround)
        {
            rb.useGravity = true;
            float jump = 10 * jumpForce;
            rb.velocity = new Vector2(rb.velocity.x, jump);
            onGround = false;
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        print("Collision!");
        if (collision.gameObject.CompareTag("Ground") ||
        collision.gameObject.CompareTag("Block") ||
        collision.gameObject.CompareTag("OrangeBlock") ||
        collision.gameObject.CompareTag("YellowBlock")) {
            onGround = true;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        print("Trigger!");
    }
}
