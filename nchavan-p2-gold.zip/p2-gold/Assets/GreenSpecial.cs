using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GreenSpecial : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        print("[Green] Trigger!");
        // Green is responsible for jump
        GameObject player = GameObject.Find("Player");
        player.GetComponent<Jump>().jumpForce = 1.25f;
    }
}
